# Overview

*  _Benef_  --  1415 instances.
*  _BenefReturn_  --  1606 instances.
*  _Risk_  --  3471 instances.
*  _Article_  --  376 instances.
*  _RiskImpact_  --  0 instances.
*  _RiskGBN_  --  5 instances.
*  _RiskMitigation_  --  5606 instances.
*  _RiskHealth_  --  14 instances.
*  _RiskType_  --  22 instances.
*  _Stakeholder_  --  2908 instances.
*  _Qid_  --  1728 instances.
*  _Technology_  --  4738 instances.
*  _RiskISO_Impact_  --  24 instances.
*  _RiskISO_Purpose_  --  19 instances.
*  _MitigationFamily_  --  0 instances.
*  _RiskImpactFamily_  --  0 instances.
*  _StakeholderGroup_  --  184 instances.
*  _StakeholderSubgroup_  --  169 instances.
*  _TechGroup_  --  210 instances.
*  _TechSubgroup_  --  191 instances.
*  _Blueprint_  --  24 instances.
*  _Intervention_  --  0 instances.
*  _MainEnabler_  --  0 instances.
*  _SecondaryEnabler_  --  0 instances.
*  _BP_Category_  --  3 instances.
*  _BP_Theme_  --  10 instances.
*  _BP_Intervention_  --  73 instances.
*  _BP_Enabler_  --  0 instances.
*  _Mitigation_  --  2485 instances.
*  _PBNThing_  --  20314 instances.
*  _RiskISO_  --  43 instances.
*  _Enabler_  --  0 instances.

# Details

##  Benef  --  1415 instances.
###  PBN__Benef_0  ->  Early detection
*  pbn_t3_5.PBN__Benef_0.has_BenefDetails :  ['Early warning system for outbreaks']
*  pbn_t3_5.PBN__Benef_0.has_BenefReturn :  [pbn_t3_5.PBN__BenefReturn_0, pbn_t3_5.PBN__BenefReturn_104, pbn_t3_5.PBN__BenefReturn_641, pbn_t3_5.PBN__BenefReturn_1093, pbn_t3_5.PBN__BenefReturn_1114]
*  pbn_t3_5.PBN__Benef_0.has_BenefSource :  [pbn_t3_5.PBN__Article_0, pbn_t3_5.PBN__Article_24, pbn_t3_5.PBN__Article_118, pbn_t3_5.PBN__Article_204, pbn_t3_5.PBN__Article_207]
*  pbn_t3_5.PBN__Benef_0.has_Beneficiary :  [pbn_t3_5.PBN__Stakeholder_0, pbn_t3_5.PBN__Stakeholder_68, pbn_t3_5.PBN__Stakeholder_2, pbn_t3_5.PBN__Stakeholder_394, pbn_t3_5.PBN__Stakeholder_397]
###  PBN__Benef_1  ->  Estimating state of infection
*  pbn_t3_5.PBN__Benef_1.has_BenefDetails :  ['WBE provides insights into the degree of infection spread in a population, helping regional health authorities estimate the state of infection in a specific region more accurately.']
*  pbn_t3_5.PBN__Benef_1.has_BenefReturn :  [pbn_t3_5.PBN__BenefReturn_1]
*  pbn_t3_5.PBN__Benef_1.has_BenefSource :  [pbn_t3_5.PBN__Article_0]
*  pbn_t3_5.PBN__Benef_1.has_Beneficiary :  [pbn_t3_5.PBN__Stakeholder_1]
###  PBN__Benef_2  ->  Assessing non-detected cases
*  pbn_t3_5.PBN__Benef_2.has_BenefDetails :  ['WBE helps in assessing the contribution of non-detected cases to the overall development of the infection, providing valuable information on the true extent of the virus spread.']
*  pbn_t3_5.PBN__Benef_2.has_BenefReturn :  [pbn_t3_5.PBN__BenefReturn_2]
*  pbn_t3_5.PBN__Benef_2.has_BenefSource :  [pbn_t3_5.PBN__Article_0]
*  pbn_t3_5.PBN__Benef_2.has_Beneficiary :  [pbn_t3_5.PBN__Stakeholder_2]
##  BenefReturn  --  1606 instances.
###  PBN__BenefReturn_0  ->  Early detection helps public health authorities implement timely interventions and prevent the spread of the virus, reducing healthcare burden and economic impact.
###  PBN__BenefReturn_104  ->  Investing in early detection measures can prevent large-scale outbreaks, protect public health, and limit economic impact.
###  PBN__BenefReturn_641  ->  Asset value increase from improved understanding and control measures
##  Risk  --  3471 instances.
###  PBN__Risk_0  ->  Spread of SARS-CoV-2 virus
*  pbn_t3_5.PBN__Risk_0.has_RiskMitigation :  [pbn_t3_5.PBN__RiskMitigation_0]
###  PBN__Risk_1  ->  Spread of SARS-CoV-2 through sewage
*  pbn_t3_5.PBN__Risk_1.has_RiskMitigation :  [pbn_t3_5.PBN__RiskMitigation_1, pbn_t3_5.PBN__RiskMitigation_2, pbn_t3_5.PBN__RiskMitigation_3, pbn_t3_5.PBN__RiskMitigation_4, pbn_t3_5.PBN__RiskMitigation_5]
###  PBN__Risk_2  ->  Domestic violence and intimate partner violence
*  pbn_t3_5.PBN__Risk_2.has_RiskMitigation :  [pbn_t3_5.PBN__RiskMitigation_6]
##  Article  --  376 instances.
###  PBN__Article_0  ->  westhaus_detection_2021
*  pbn_t3_5.PBN__Article_0.has_ArticleYear :  ['2021']
*  pbn_t3_5.PBN__Article_0.has_ArticleDOI :  ['10.1016/j.scitotenv.2020.141750']
*  pbn_t3_5.PBN__Article_0.has_ArticleRef :  [pbn_t3_5.PBN__Article_205, pbn_t3_5.PBN__Article_37, pbn_t3_5.PBN__Article_70, pbn_t3_5.PBN__Article_1, pbn_t3_5.PBN__Article_96, pbn_t3_5.PBN__Article_21]
*  pbn_t3_5.PBN__Article_0.has_ArticleLLMSummary :  ["Scientists conducted a study to see if they could find traces of the new coronavirus in wastewater, which is the water that goes down the drain from homes and businesses. They collected samples from different wastewater treatment plants in Germany and tested them for genetic material from the virus. They found that the virus's genetic material was present in the wastewater, which suggests that it can be detected this way. They also compared the amount of genetic material in the water and in solid waste, and found that there was more in the solid waste. However, they found that the wastewater samples did not contain live, infectious virus particles. This means that although the genetic material is present in the wastewater, it is not likely to make people sick."]
*  pbn_t3_5.PBN__Article_0.has_ArticleTitle :  ['Detection of SARS-CoV-2 in raw and treated wastewater in Germany – Suitability for COVID-19 surveillance and potential transmission risks']
*  pbn_t3_5.PBN__Article_0.has_ArticleLLMShortSummary :  ['This study investigated the presence of SARS-CoV-2 genetic material in wastewater samples collected from nine municipal wastewater treatment plants in Germany during the height of the COVID-19 pandemic. The samples were analyzed using reverse transcription-quantitative polymerase chain reaction (RT-qPCR) to detect specific genes of the virus, as well as pan-genotypic gene sequences of other coronaviruses. The study found that SARS-CoV-2 RNA was detected in the untreated wastewater samples, indicating the presence of the virus in the population. The RT-qPCR analysis also showed differences in the concentration of SARS-CoV-2 genetic material between the solid and liquid phases of the wastewater samples. While the viral RNA was detected in the solid phase, its concentration was higher in the liquid phase, possibly due to the repartitioning of genetic material during wastewater treatment. The study also found that the detected SARS-CoV-2 genetic material in the wastewater samples was non-infectious based on tests conducted on cultured cells. Overall, this study demonstrates the potential of wastewater-based monitoring as a tool to track the spread of SARS-CoV-2 in a population.']
###  PBN__Article_24  ->  wang_response_2020
*  pbn_t3_5.PBN__Article_24.has_ArticleYear :  ['2020']
*  pbn_t3_5.PBN__Article_24.has_ArticleDOI :  ['10.1001/jama.2020.3151']
*  pbn_t3_5.PBN__Article_24.has_ArticleLLMSummary :  ["Taiwan is a country that is close to China and was expected to have a lot of cases of the coronavirus. But they took quick action to prevent the spread of the virus. They sent health declaration passes to people's phones to make it easier for them to go through immigration. If someone had traveled to a high-risk area, they were quarantined at home and monitored through their phones. Taiwan also found cases of the virus by testing people with severe respiratory symptoms. They set up a hotline for people to report any symptoms or cases they knew about. The government made sure that people under quarantine had food and regular health checks. They also provided information to the public through announcements by important officials. Overall, Taiwan did a good job in responding to the crisis and protecting its citizens."]
*  pbn_t3_5.PBN__Article_24.has_ArticleTitle :  ['Response to COVID-19 in Taiwan: Big Data Analytics, New Technology, and Proactive Testing']
*  pbn_t3_5.PBN__Article_24.has_ArticleLLMShortSummary :  ["Taiwan has implemented various proactive measures to prevent the spread of COVID-19 and minimize the impact of the epidemic. These measures include border control, case identification, containment, resource allocation, public reassurance and education, and effective communication strategies. The National Health Insurance Administration (NHIA) and the National Immigration Agency integrated patients' travel history with their NHI identification card data, allowing the government to track individuals at high risk. Those identified as high risk were monitored electronically through their mobile phones. The government also established the National Health Command Center (NHCC) as the operational command point for direct communications among central, regional, and local authorities. Taiwan has rapidly implemented over 120 action items, including border control, case identification, quarantine measures, resource allocation, and public education. The government has communicated with the public in a clear and compassionate manner, with high approval ratings for their handling of the crisis. Challenges faced include language barriers for non-Taiwanese citizens and the docking of a cruise ship with confirmed infections. Taiwan's experience highlights the importance of early recognition, timely and transparent information delivery, and effective crisis management in responding to a public health crisis."]
###  PBN__Article_118  ->  wu_current_2021
*  pbn_t3_5.PBN__Article_118.has_ArticleYear :  ['2021']
*  pbn_t3_5.PBN__Article_118.has_ArticleDOI :  ['10.1016/j.bsheal.2021.06.001']
*  pbn_t3_5.PBN__Article_118.has_ArticleLLMSummary :  ["Scientists have been studying COVID-19 to find out where it comes from and how it affects our bodies. They think the virus may have come from bats, but they're not sure yet. Some other animals, like pangolins and salmon, can also get similar viruses. They're studying these animals to help make vaccines and treatments for COVID-19. The virus can enter our cells through a special protein and can affect different parts of our body, not just our lungs. Older people and men are more likely to get sick from the virus. It spreads from person to person through coughing, sneezing, and talking, so it's important to wear masks and wash our hands. Scientists are also working on developing vaccines and medicines to treat COVID-19. In the future, we need to keep studying viruses and be prepared for new ones to keep us safe."]
*  pbn_t3_5.PBN__Article_118.has_ArticleTitle :  ['Current knowledge of COVID-19: Advances, challenges and future perspectives']
*  pbn_t3_5.PBN__Article_118.has_ArticleLLMShortSummary :  ['This review article provides a summary of current knowledge on various aspects of COVID-19, including the origin of the SARS-CoV-2 virus, its cell entry mechanisms, tissue tropism, and pathogenesis. The review discusses the potential animal hosts of the virus, such as bats and pangolins, and highlights the need to identify the "Patient Zero" to better understand the emergence of the virus. The article also explores the different receptors and factors involved in virus entry into host cells, as well as the organ systems affected by COVID-19, including the respiratory system, gastrointestinal system, and central nervous system. Additionally, the review examines population susceptibility to the virus, with a focus on age, gender, and blood type. The article also discusses key factors contributing to the transmission of the virus, such as close contact, respiratory droplets, and surface contamination, and highlights the importance of vaccines and drugs in combating the disease. The review concludes by emphasizing the need for ongoing surveillance of coronaviruses and the development of broad-spectrum antiviral drugs and universal vaccines to prepare for future outbreaks of emerging infectious diseases.']
##  RiskImpact  --  0 instances.
##  RiskGBN  --  5 instances.
###  PBN__RiskGBN_0  ->  No
###  PBN__RiskGBN_1  ->  Yes
###  PBN__RiskGBN_2  ->  nan
##  RiskMitigation  --  5606 instances.
###  PBN__RiskMitigation_0  ->  Wastewater-based monitoring (WBE)
*  pbn_t3_5.PBN__RiskMitigation_0.has_MitigationBenefit :  [pbn_t3_5.PBN__Benef_0, pbn_t3_5.PBN__Benef_1, pbn_t3_5.PBN__Benef_2, pbn_t3_5.PBN__Benef_3, pbn_t3_5.PBN__Benef_4]
###  PBN__RiskMitigation_1  ->  Sewage surveillance
*  pbn_t3_5.PBN__RiskMitigation_1.has_MitigationBenefit :  [pbn_t3_5.PBN__Benef_5]
###  PBN__RiskMitigation_2  ->  Improved controls for monitoring virus recovery efficiency
*  pbn_t3_5.PBN__RiskMitigation_2.has_MitigationBenefit :  [pbn_t3_5.PBN__Benef_6]
##  RiskHealth  --  14 instances.
###  PBN__RiskHealth_6  ->  nan
###  PBN__RiskHealth_0  ->  physical
###  PBN__RiskHealth_2  ->  other
##  RiskType  --  22 instances.
###  PBN__RiskType_3  ->  economic
###  PBN__RiskType_2  ->  social
###  PBN__RiskType_0  ->  environmental
##  Stakeholder  --  2908 instances.
###  PBN__Stakeholder_0  ->  public health authorities
###  PBN__Stakeholder_68  ->  healthcare workers
*  pbn_t3_5.PBN__Stakeholder_68.has_StakeholderGroup :  [pbn_t3_5.PBN__StakeholderGroup_4]
*  pbn_t3_5.PBN__Stakeholder_68.has_StakeholderID :  [pbn_t3_5.nan]
*  pbn_t3_5.PBN__Stakeholder_68.has_StakeholderSubgroup :  [pbn_t3_5.PBN__StakeholderSubgroup_7]
###  PBN__Stakeholder_2  ->  researchers
*  pbn_t3_5.PBN__Stakeholder_2.has_StakeholderID :  [pbn_t3_5.Q1650915]
##  Qid  --  1728 instances.
###  Q1650915  ->  researchers
*  pbn_t3_5.Q1650915.has_Qid_alias :  ['researchers', 'building occupant and researcher', 'research personnel', 'research person', 'research persons', 'investigator', 'Researchers', 'principal investigator', 'co-investigator', 'one senior researcher', 'researcher and reader', 'research staff', 'recent research efforts']
###  Q3907287  ->  policy makers
*  pbn_t3_5.Q3907287.has_Qid_alias :  ['policy makers', 'policy-makers', 'policy making', 'limited data for policy-making', 'knowledge to policy (k2p)', 'decisionand policy-making', 'policy dialogue', 'intensive policy maintenance', 'policies development', 'policy intervention', 'policy-maker', 'design of policy', 'policy engagement', 'policy-and practice-relevant priorities', 'policy package', 'knowledge to policy', 'policymaker', 'preparatory policies', 'policy maker', 'policy deployment', 'effective policy decisionmaking', 'policy decision-making', 'policy development', 'policy tool', 'policy-making', 'key implications for policy and practice', 'policy communication', 'policy-and practice-relevant', 'limited information for policy decision-making', 'policymaking', 'ensuring policy adherence until the end', 'policy recommendation']
###  Q177634  ->  communities
*  pbn_t3_5.Q177634.has_Qid_alias :  ['communities', 'community members', 'community', 'underserved communities', 'especially those in underserved communities', 'community group', 'Community', 'Communities', 'community life circles', 'communities in higher-risk areas', '10-min community life circle', 'community-centered', '15-min community life circle', 'community relationships', 'smart community', 'community-level key places', 'community life circle', '5-min community life circles', 'pcaadjacent communities', 'potential community spread', 'in the community', 'community led', 'human communities', 'poorer communities', 'open communities', 'individual community', '5-min community', '15-min community living circles', 'community-level', 'smart communities', 'community update', 'communities of color', 'community/site', 'open community', 'human community', 'broader <subj>communities', '5-min community living circle', 'the community led', 'community life', '10-min communities', 'community as a whole', '5-min and 15-min community living circles', 'community relationship', 'community living circle', 'communities at high risk', 'community level', 'lack of community connections', '"community"', '15-min community', '15-10-5-min community life circle', 'composite communities', '10-min community living circle', '5-min community life circle', 'community assemblages']
##  Technology  --  4738 instances.
###  PBN__Technology_816  ->  digital communication
*  pbn_t3_5.PBN__Technology_816.has_TechnologyID :  [pbn_t3_5.Q10481248]
###  PBN__Technology_817  ->  supply chain management platforms
*  pbn_t3_5.PBN__Technology_817.has_TechnologyID :  [pbn_t3_5.Q492886]
###  PBN__Technology_1130  ->  advanced analytics and simulation models
*  pbn_t3_5.PBN__Technology_1130.has_TechnologyID :  [pbn_t3_5.Q7263963]
##  RiskISO_Impact  --  24 instances.
###  PBN__RiskISO_Impact_2  ->  Resilience
###  PBN__RiskISO_Impact_3  ->  Health and care
###  PBN__RiskISO_Impact_4  ->  Responsible resource use
##  RiskISO_Purpose  --  19 instances.
###  PBN__RiskISO_Purpose_8  ->  Economy and sustainable production and consumption
###  PBN__RiskISO_Purpose_0  ->  Health and care
###  PBN__RiskISO_Purpose_9  ->  Community infrastructures
##  MitigationFamily  --  0 instances.
##  RiskImpactFamily  --  0 instances.
##  StakeholderGroup  --  184 instances.
###  PBN__StakeholderGroup_6  ->  Vulnerable Population
###  PBN__StakeholderGroup_9  ->  Individuals
###  PBN__StakeholderGroup_5  ->  Private Sector
##  StakeholderSubgroup  --  169 instances.
###  PBN__StakeholderSubgroup_113  ->  Personal Safety and Security
###  PBN__StakeholderSubgroup_147  ->  Public
###  PBN__StakeholderSubgroup_31  ->  Real Estate and Construction
##  TechGroup  --  210 instances.
###  PBN__TechGroup_6  ->  Surveillance systems
###  PBN__TechGroup_4  ->  Infrastructure
###  PBN__TechGroup_0  ->  AI tools
##  TechSubgroup  --  191 instances.
###  PBN__TechSubgroup_147  ->  Surveillance and Monitoring Systems
###  PBN__TechSubgroup_7  ->  nan
###  PBN__TechSubgroup_3  ->  Communication and Data Sharing
##  Blueprint  --  24 instances.
###  PBN__Blueprint_0  ->  PBN:BP_1
*  pbn_t3_5.PBN__Blueprint_0.has_BPTransmission :  ['Airborne & Respiratory & Direct Contact']
*  pbn_t3_5.PBN__Blueprint_0.has_BPType :  ['Behavioural']
*  pbn_t3_5.PBN__Blueprint_0.has_BPProblem :  ['Reduced possibility of disease transmission due to less crowded areas, less social mixing between staff groups, and reduced disruption of services due to unavailable labour.']
*  pbn_t3_5.PBN__Blueprint_0.has_BPDemonstrated :  ['https://doi.org/10.1371/journal.pcbi.1009264']
*  pbn_t3_5.PBN__Blueprint_0.has_BPContext :  ['This measure should be used applied in enclosed and busy areas such as offices (during working hours) or large retail outlets during morning and evening rush hours and at weekends. For this measure to work, greater flexibility is envisaged on the part of the main actors - the workers - who should be willing to accept the restriction of their access.']
*  pbn_t3_5.PBN__Blueprint_0.has_BPCapabilities :  ['The good functioning of the rotational shift system is based on three main pillars:\n• a shift booking system that assigns workers to specific groups depending onaccording to  the specific epidemiological situation\n• education of users through information campaigns about the logic of this measure \n• a robust testing and shift coverage plan for a quick response time in case of infection in one of the groups']
*  pbn_t3_5.PBN__Blueprint_0.has_BPPhase :  ['Operational']
*  pbn_t3_5.PBN__Blueprint_0.has_BPDescription :  ['During the COVID-19 pandemic, large organisations, as well as many educational public institutions, explored the potential to reduce disease transmission by dividing their staff (and students)and users into smaller groups that take turns using and servicing physical space in enclosed and high-traffic areas. The main idea is to introduce a rotating shift schedule in high occupancy areas, focusing on managing staff presence through shifts rather than the potential users of the services provided. Workers Staff should remain with the same shift group to reduce social mixing between groups of staff.']
*  pbn_t3_5.PBN__Blueprint_0.has_BPRestriction :  ['A number of limitations and constraints were identified for this specific measure:\n•\t non-acceptance by users \n•\t change of behavioural patterns\n•\t risk of duplication of resources - inefficiencies in the organisation could result in higher costs to end users to mitigate financial impact\n•\t better planning needed, including testing for users\n•\t misinformation\n•\t slow response time\n•\t number of users']
*  pbn_t3_5.PBN__Blueprint_0.has_BPScale :  ['Building']
*  pbn_t3_5.PBN__Blueprint_0.has_BPPermanent :  ['Temporary']
*  pbn_t3_5.PBN__Blueprint_0.has_BPValueProposition :  ['IThe implementation of this measure will allow control over occupancy, while maintaining the quality of services and productivity at the usual level and providing flexibility to the end users of these services.']
*  pbn_t3_5.PBN__Blueprint_0.has_BPReason :  ['Limiting the occupancy of enclosed spaces allows for better social distancing. In addition, rotating the workforcerotation of staff prevents the transmission of diseases between the majority of staff, thus maintaining the final quality of service and bringing providing more flexibility to clients.  ']
*  pbn_t3_5.PBN__Blueprint_0.has_BPTitle :  ['Rotating shift schedule']
###  PBN__Blueprint_1  ->  PBN:BP_2
*  pbn_t3_5.PBN__Blueprint_1.has_BPTransmission :  ['Direct contact & Fomite']
*  pbn_t3_5.PBN__Blueprint_1.has_BPType :  ['Technical']
*  pbn_t3_5.PBN__Blueprint_1.has_BPProblem :  ['This solution ensures non-contact delivery of goods, minimising the transmission of diseases through the delivery of goods from the shop to the customer. In addition, this measure prevents overcrowding by avoiding bottlenecks caused by queues during collection or the goods being lost, stolen or broken.  Last but not least, smart lockers will reduce operating costs and provide savings for commercial properties.']
*  pbn_t3_5.PBN__Blueprint_1.has_BPDemonstrated :  ['https://smiota.com/resources/the-impact-of-smart-parcel-lockers-on-campus-pre-and-post-covid-19/']
*  pbn_t3_5.PBN__Blueprint_1.has_BPContext :  ['Due to their nature, smart lockers can be accessible 24 hours a day, leaving it up to the customer to decide whether to access them within a certain period of time, which depends on traffic, but in almost all cases is no less than 24 hours. As some other industries have realised, this solution can also be applied to their needs. The hospitality industry, as well as many large corporations and universities, are using this measure to encourage touch-free delivery of food, documents, books, etc. in areas with somewhat higher occupancy rates. As mentioned earlier, the lockers must be placed in a specific location and continuous activity must be guaranteed even when the end user is not present.']
*  pbn_t3_5.PBN__Blueprint_1.has_BPCapabilities :  ['A number of prerequisites are necessary for the implementation of this measure. These include the smart lockers themselves, the placement of these lockers, a mobile app that allows both businesses and their customers track and manage the delivery of goods, and a robust logistics plan to make delivery not only cost-effective but also flexible.']
*  pbn_t3_5.PBN__Blueprint_1.has_BPPhase :  ['Operational']
*  pbn_t3_5.PBN__Blueprint_1.has_BPDescription :  ['Following the outbreak of COVID-19 pandemic, e-commerce companies have invested heavily in the development of contactless parcel delivery networks, particularly smart locker technologies that eliminate any person-to-person contact when the order is picked up by a special password or QR code in a dedicated room that can be enhanced with other measures to protect against transmissions. This could be extended to any GBN, especially for local delivery of goods.']
*  pbn_t3_5.PBN__Blueprint_1.has_BPRestriction :  ["A number of limitations have been identified for this specific measure:\n•\t most of today's systems cannot automatically close the locker door: it is not contactless. \n•\t older adults' perceptions of technology and barriers to interaction.\n•\t non-acceptance by users\n•\t vandalism\n•\t need for good cleaning of the locker system\n•\t system crash\n•\t power outages\n•\t need for strict hygiene measures in the area where the lockers are located\n•\t carrying capacity at peak time - limited capacity if the user does not collect the goods quickly\n•\t inability to carry large parcels \n•\t partial job destruction"]
*  pbn_t3_5.PBN__Blueprint_1.has_BPScale :  ['Building']
*  pbn_t3_5.PBN__Blueprint_1.has_BPPermanent :  ['Permanent ']
*  pbn_t3_5.PBN__Blueprint_1.has_BPValueProposition :  ['The smart locker system is widely seen as a innovative way to attract new customers and/or visitors by offering them more flexibility (in terms of time and choice of delivery location) and optimised delivery of their goods.']
*  pbn_t3_5.PBN__Blueprint_1.has_BPReason :  ['Smart lockers allow their users to collect their goods more safely in terms of contagious disease risks, as contactless delivery promotes better social distancing. It also makes collection more convenient, as consumers can choose from a wide range of collection locations and times. From a business perspective, smart lockers allow for more cost-efficient and flexible delivery of goods as the system is simpler compared to traditional methods. In addition, the transport of goods is more secure as every single step can be tracked through automated protocols.']
*  pbn_t3_5.PBN__Blueprint_1.has_BPTitle :  ['Smart Locker System ']
###  PBN__Blueprint_2  ->  PBN:BP_3
*  pbn_t3_5.PBN__Blueprint_2.has_BPTransmission :  ['All']
*  pbn_t3_5.PBN__Blueprint_2.has_BPType :  ['Technical & Behavioural']
*  pbn_t3_5.PBN__Blueprint_2.has_BPProblem :  ['The main problem solved by this measure is the fact that previous architectural designs did not take precautions to minimise contamination, especially with regard to social distancing, hygiene measures or the use of other built-in solutions.']
*  pbn_t3_5.PBN__Blueprint_2.has_BPDemonstrated :  ['https://www.newyorker.com/culture/dept-of-design/how-the-coronavirus-will-reshape-architecture ']
*  pbn_t3_5.PBN__Blueprint_2.has_BPContext :  ['This measure is especially important at the beginning of the planning phase of new or renovated buildings and spaces. There is a consensus that the trend is towards larger and less dense spaces with lower capacity and better ventilation. ']
*  pbn_t3_5.PBN__Blueprint_2.has_BPCapabilities :  ['To implement this measure as effectively as possible, a good understanding of the right way to design architecture and the related context of systems thinking is crucial. Lessons learned from previous health events have already been incorporated into a new approach to architecture in various ways, for example by promoting smooth surfaces and geometric design to reduce the problem of dust accumulation and other contaminants. ']
*  pbn_t3_5.PBN__Blueprint_2.has_BPPhase :  ['Design']
*  pbn_t3_5.PBN__Blueprint_2.has_BPDescription :  ['The COVID-19 pandemic has greatly impacted densely populated areas. It is recognized that there is an urgent need to rethink architectural design processes and choose the right designs that can minimise the risk of contamination between users of the space. The move away from open-space concepts in separate spaces is already evident in many short-term solutions for redesigning spaces, so to take into account the reduction of contamination risks.']
*  pbn_t3_5.PBN__Blueprint_2.has_BPRestriction :  ['The main obstacle is that it is very difficult to apply these features to existing designs and/or buildings. Another limitation could be the current state of the art, e.g. ventilation systems, automatic doors and other non-contact features that have only been studied in more detail in recent years. The constructuon of transmission-prone buildings can also be costly.']
*  pbn_t3_5.PBN__Blueprint_2.has_BPScale :  ['Building']
*  pbn_t3_5.PBN__Blueprint_2.has_BPPermanent :  ['Permanent ']
*  pbn_t3_5.PBN__Blueprint_2.has_BPValueProposition :  ['Embedding general resilience and specific mitigation measures into architectural design will have the effect of reducing the additional costs that could be incurred in the event of a health event. As there is a global trend is towards more resilient infrastructure, incorporating this measure at the beginning of the project will certainly lead to future standards being met later down the line.']
*  pbn_t3_5.PBN__Blueprint_2.has_BPReason :  ['More and more architectural projects implement mitigation measures at the outset so that the users of the physical space can actually comply with these measures, especially in terms of social distancing. This helps avoid additional ad hoc measures if the architectural design is carried out properly, and the measures are an integral part of the building from the very beginning']
*  pbn_t3_5.PBN__Blueprint_2.has_BPTitle :  ['Adapted architectural design ']
##  Intervention  --  0 instances.
##  MainEnabler  --  0 instances.
##  SecondaryEnabler  --  0 instances.
##  BP_Category  --  3 instances.
###  PBN__BP_Category_0  ->  category_Prevention
*  pbn_t3_5.PBN__BP_Category_0.has_BP_Theme :  [pbn_t3_5.PBN__BP_Theme_0, pbn_t3_5.PBN__BP_Theme_1, pbn_t3_5.PBN__BP_Theme_2]
*  pbn_t3_5.PBN__BP_Category_0.has_BP_CategoryTitle :  ['Prevention']
###  PBN__BP_Category_1  ->  category_Human-centered
*  pbn_t3_5.PBN__BP_Category_1.has_BP_Theme :  [pbn_t3_5.PBN__BP_Theme_3, pbn_t3_5.PBN__BP_Theme_4, pbn_t3_5.PBN__BP_Theme_5, pbn_t3_5.PBN__BP_Theme_6]
*  pbn_t3_5.PBN__BP_Category_1.has_BP_CategoryTitle :  ['Human-centered']
###  PBN__BP_Category_2  ->  category_Manage
*  pbn_t3_5.PBN__BP_Category_2.has_BP_Theme :  [pbn_t3_5.PBN__BP_Theme_7, pbn_t3_5.PBN__BP_Theme_8, pbn_t3_5.PBN__BP_Theme_9]
*  pbn_t3_5.PBN__BP_Category_2.has_BP_CategoryTitle :  ['Manage']
##  BP_Theme  --  10 instances.
###  PBN__BP_Theme_0  ->  theme_Air_Quality
*  pbn_t3_5.PBN__BP_Theme_0.has_BP_ThemeTitle :  ['Air Quality']
*  pbn_t3_5.PBN__BP_Theme_0.has_BP_Intervention :  [pbn_t3_5.PBN__BP_Intervention_0, pbn_t3_5.PBN__BP_Intervention_1, pbn_t3_5.PBN__BP_Intervention_2, pbn_t3_5.PBN__BP_Intervention_3, pbn_t3_5.PBN__BP_Intervention_4, pbn_t3_5.PBN__BP_Intervention_5, pbn_t3_5.PBN__BP_Intervention_6, pbn_t3_5.PBN__BP_Intervention_7]
###  PBN__BP_Theme_1  ->  theme_Water_Quality
*  pbn_t3_5.PBN__BP_Theme_1.has_BP_ThemeTitle :  ['Water Quality']
*  pbn_t3_5.PBN__BP_Theme_1.has_BP_Intervention :  [pbn_t3_5.PBN__BP_Intervention_8, pbn_t3_5.PBN__BP_Intervention_9, pbn_t3_5.PBN__BP_Intervention_10, pbn_t3_5.PBN__BP_Intervention_11]
###  PBN__BP_Theme_2  ->  theme_Sanitizing
*  pbn_t3_5.PBN__BP_Theme_2.has_BP_ThemeTitle :  ['Sanitizing']
*  pbn_t3_5.PBN__BP_Theme_2.has_BP_Intervention :  [pbn_t3_5.PBN__BP_Intervention_12, pbn_t3_5.PBN__BP_Intervention_13, pbn_t3_5.PBN__BP_Intervention_14, pbn_t3_5.PBN__BP_Intervention_15, pbn_t3_5.PBN__BP_Intervention_16]
##  BP_Intervention  --  73 instances.
###  PBN__BP_Intervention_0  ->  intervention_PA1
*  pbn_t3_5.PBN__BP_Intervention_0.has_BP_InterventionTitle :  ['Use of smart/innovative air quality controls technology']
*  pbn_t3_5.PBN__BP_Intervention_0.has_BP_InterventionKey :  ['PA1']
###  PBN__BP_Intervention_1  ->  intervention_PA2
*  pbn_t3_5.PBN__BP_Intervention_1.has_BP_InterventionTitle :  ['Environmental parameters control']
*  pbn_t3_5.PBN__BP_Intervention_1.has_BP_InterventionKey :  ['PA2']
###  PBN__BP_Intervention_2  ->  intervention_PA3
*  pbn_t3_5.PBN__BP_Intervention_2.has_BP_InterventionTitle :  ['Air filtration']
*  pbn_t3_5.PBN__BP_Intervention_2.has_BP_InterventionKey :  ['PA3']
##  BP_Enabler  --  0 instances.
##  Mitigation  --  2485 instances.
###  PBN__Mitigation_739  ->  Garden access
*  pbn_t3_5.PBN__Mitigation_739.has_MitigationPrinciple :  ['Shift harm from home by providing access to gardens and outdoor spaces for relaxation and well-being']
*  pbn_t3_5.PBN__Mitigation_739.has_MitigationTechnology :  [pbn_t3_5.PBN__Technology_3419]
*  pbn_t3_5.PBN__Mitigation_739.has_MitigationSource :  [pbn_t3_5.PBN__Article_2]
###  PBN__Mitigation_741  ->  Well-being support
*  pbn_t3_5.PBN__Mitigation_741.has_MitigationPrinciple :  ['Shift harm from home by providing access to mental health support and services']
*  pbn_t3_5.PBN__Mitigation_741.has_MitigationTechnology :  [pbn_t3_5.PBN__Technology_1080, pbn_t3_5.PBN__Technology_3422]
*  pbn_t3_5.PBN__Mitigation_741.has_MitigationSource :  [pbn_t3_5.PBN__Article_2]
###  PBN__Mitigation_734  ->  Policy interventions
*  pbn_t3_5.PBN__Mitigation_734.has_MitigationPrinciple :  ['Shift and reduce harm by improving the quality of neighbourhoods and communities to reduce the risk of health harming behaviors and social harm', 'Shift harm from home through targeted policies and interventions that address mental health and well-being']
*  pbn_t3_5.PBN__Mitigation_734.has_MitigationTechnology :  [pbn_t3_5.PBN__Technology_3414, pbn_t3_5.PBN__Technology_1177, pbn_t3_5.PBN__Technology_3423]
*  pbn_t3_5.PBN__Mitigation_734.has_MitigationSource :  [pbn_t3_5.PBN__Article_2]
##  PBNThing  --  20314 instances.
###  PBN__Benef_0  ->  Early detection
*  pbn_t3_5.PBN__Benef_0.has_BenefDetails :  ['Early warning system for outbreaks']
*  pbn_t3_5.PBN__Benef_0.has_BenefReturn :  [pbn_t3_5.PBN__BenefReturn_0, pbn_t3_5.PBN__BenefReturn_104, pbn_t3_5.PBN__BenefReturn_641, pbn_t3_5.PBN__BenefReturn_1093, pbn_t3_5.PBN__BenefReturn_1114]
*  pbn_t3_5.PBN__Benef_0.has_BenefSource :  [pbn_t3_5.PBN__Article_0, pbn_t3_5.PBN__Article_24, pbn_t3_5.PBN__Article_118, pbn_t3_5.PBN__Article_204, pbn_t3_5.PBN__Article_207]
*  pbn_t3_5.PBN__Benef_0.has_Beneficiary :  [pbn_t3_5.PBN__Stakeholder_0, pbn_t3_5.PBN__Stakeholder_68, pbn_t3_5.PBN__Stakeholder_2, pbn_t3_5.PBN__Stakeholder_394, pbn_t3_5.PBN__Stakeholder_397]
###  PBN__Benef_1  ->  Estimating state of infection
*  pbn_t3_5.PBN__Benef_1.has_BenefDetails :  ['WBE provides insights into the degree of infection spread in a population, helping regional health authorities estimate the state of infection in a specific region more accurately.']
*  pbn_t3_5.PBN__Benef_1.has_BenefReturn :  [pbn_t3_5.PBN__BenefReturn_1]
*  pbn_t3_5.PBN__Benef_1.has_BenefSource :  [pbn_t3_5.PBN__Article_0]
*  pbn_t3_5.PBN__Benef_1.has_Beneficiary :  [pbn_t3_5.PBN__Stakeholder_1]
###  PBN__Benef_2  ->  Assessing non-detected cases
*  pbn_t3_5.PBN__Benef_2.has_BenefDetails :  ['WBE helps in assessing the contribution of non-detected cases to the overall development of the infection, providing valuable information on the true extent of the virus spread.']
*  pbn_t3_5.PBN__Benef_2.has_BenefReturn :  [pbn_t3_5.PBN__BenefReturn_2]
*  pbn_t3_5.PBN__Benef_2.has_BenefSource :  [pbn_t3_5.PBN__Article_0]
*  pbn_t3_5.PBN__Benef_2.has_Beneficiary :  [pbn_t3_5.PBN__Stakeholder_2]
##  RiskISO  --  43 instances.
###  PBN__RiskISO_Impact_2  ->  Resilience
###  PBN__RiskISO_Impact_3  ->  Health and care
###  PBN__RiskISO_Impact_4  ->  Responsible resource use
##  Enabler  --  0 instances.